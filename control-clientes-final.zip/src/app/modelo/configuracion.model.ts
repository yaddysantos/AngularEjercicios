export interface Configuracion{
    permitirRegistro?: boolean;
}