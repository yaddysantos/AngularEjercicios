export const environment = {
  production: true,
  firestore:{
    apiKey: "AIzaSyCnkG9bLWPc9EbZMoXB51uZVzbdM8vTK0E",
    authDomain: "control-clientes-fba37.firebaseapp.com",
    databaseURL: "https://control-clientes-fba37.firebaseio.com",
    projectId: "control-clientes-fba37",
    storageBucket: "control-clientes-fba37.appspot.com",
    messagingSenderId: "340203378215"
  }
};
